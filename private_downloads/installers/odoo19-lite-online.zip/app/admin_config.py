#!/usr/bin/env python3
"""
Admin Configuration - Change these values!
"""

# ⚠️ تغییر دهید: اطلاعات ورود ادمین
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "odoo@2025"  # یک رمز قوی انتخاب کنید

# کلید مخفی برای JWT token
JWT_SECRET = "OdooInstallerAdminJWT2025SecretKey"

# مدت اعتبار session (ثانیه)
SESSION_TIMEOUT = 3600  # 1 ساعت
