& 'D:\business\odoo\odoo 19\venv\Scripts\pip.exe' install --no-index --find-links 'D:\business\odoo\Setup odoo19\offline\wheels' -r 'D:\business\odoo\Setup odoo19\offline\requirements.txt'
